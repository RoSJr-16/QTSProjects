let resp = await fetch('http://192.168.0.164:3000/usuarios')
let dados = await resp.json()

test("Teste", async ()=>{

    expect(10).toBe(dados.length)

    expect(1).toBe(dados[0].id)
    expect('Ana Silva').toBe(dados[0].nome)

    expect(10).toBe(dados[9].id)
    expect('João Pereira').toBe(dados[9].nome)
})