import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const arquivoUsuarios = path.join(__dirname, '..', 'usuarios.json');

const usuariosOriginais = JSON.parse(fs.readFileSync(arquivoUsuarios, 'utf8'));
let usuarios = structuredClone(usuariosOriginais);

function verificarLogin(login, senha) {
  return usuarios.find(usuario => usuario.login === login && usuario.senha === senha) ?? null;
}

function retornarTodos() {
  return [...usuarios];
}

function retornarAdministradores() {
  return usuarios.filter(usuario => usuario.administrador === true);
}

function retornarNaoAdministradores() {
  return usuarios.filter(usuario => usuario.administrador === false);
}

function incluirUsuario(novoUsuario) {
  if (!novoUsuario || novoUsuario.id == null || !novoUsuario.login || !novoUsuario.senha) {
    throw new Error('Usuário inválido: id, login e senha são obrigatórios.');
  }

  if (usuarios.some(usuario => usuario.id === novoUsuario.id)) {
    throw new Error('Já existe um usuário com esse id.');
  }

  if (usuarios.some(usuario => usuario.login === novoUsuario.login)) {
    throw new Error('Já existe um usuário com esse login.');
  }

  const usuario = { ...novoUsuario, administrador: novoUsuario.administrador === true };
  usuarios.push(usuario);
  return usuario;
}

function apagarUsuario(id) {
  const indice = usuarios.findIndex(usuario => usuario.id === id);
  if (indice === -1) return null;
  return usuarios.splice(indice, 1)[0];
}

function atualizarUsuario(id, dados) {
  const indice = usuarios.findIndex(usuario => usuario.id === id);
  if (indice === -1) return null;

  if (dados.login && usuarios.some((usuario, i) => i !== indice && usuario.login === dados.login)) {
    throw new Error('Já existe um usuário com esse login.');
  }

  const atualizado = {
    ...usuarios[indice],
    ...dados,
    id: usuarios[indice].id,
    administrador: dados.administrador === undefined
      ? usuarios[indice].administrador
      : dados.administrador === true
  };

  usuarios[indice] = atualizado;
  return atualizado;
}

function resetarUsuarios() {
  usuarios = structuredClone(usuariosOriginais);
}

export {
  verificarLogin,
  retornarTodos,
  retornarAdministradores,
  retornarNaoAdministradores,
  incluirUsuario,
  apagarUsuario,
  atualizarUsuario,
  resetarUsuarios
};
