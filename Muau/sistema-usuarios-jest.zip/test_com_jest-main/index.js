export {
  verificarLogin,
  retornarTodos,
  retornarAdministradores,
  retornarNaoAdministradores,
  incluirUsuario,
  apagarUsuario,
  atualizarUsuario,
  resetarUsuarios
} from './operacoes/usuarios.js';

export { somar, subtrair, multiplicar, dividir } from './operacoes/opc.js';
