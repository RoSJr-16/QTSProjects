# Sistema de Usuários com Jest

Projeto desenvolvido a partir da estrutura original, acrescentando operações sobre uma lista de 10 usuários em JSON.

## Funcionalidades

1. Verificar login e senha.
2. Retornar todos os usuários.
3. Retornar somente administradores.
4. Retornar somente não administradores.
5. Incluir usuário.
6. Apagar usuário.
7. Atualizar usuário.

## Estrutura

- `usuarios.json`: lista inicial dos 10 usuários.
- `operacoes/usuarios.js`: regras das operações.
- `test/usuarios.test.js`: testes automatizados com Jest.
- `operacoes/opc.js`: operações matemáticas originais do projeto.
- `test/opc.test.js`: testes originais.

## Executar

```bash
npm install
npm test
```

Para cobertura:

```bash
npm run test:cov
```

> As operações são feitas em memória durante a execução dos testes; o arquivo `usuarios.json` funciona como fonte inicial dos dados.
