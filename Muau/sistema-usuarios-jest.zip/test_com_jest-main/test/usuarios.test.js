import {
  verificarLogin,
  retornarTodos,
  retornarAdministradores,
  retornarNaoAdministradores,
  incluirUsuario,
  apagarUsuario,
  atualizarUsuario,
  resetarUsuarios
} from '../operacoes/usuarios.js';

beforeEach(() => resetarUsuarios());

test('verificar login e senha de usuário existente', () => {
  const usuario = verificarLogin('ana', '123456');
  expect(usuario).not.toBeNull();
  expect(usuario.login).toBe('ana');
});

test('rejeitar login e senha incorretos', () => {
  expect(verificarLogin('ana', 'senha-errada')).toBeNull();
  expect(verificarLogin('usuario-inexistente', '123456')).toBeNull();
});

test('retornar todos os usuários', () => {
  const usuarios = retornarTodos();
  expect(usuarios).toHaveLength(10);
  expect(usuarios[0].nome).toBe('Ana Silva');
});

test('retornar apenas administradores', () => {
  const administradores = retornarAdministradores();
  expect(administradores).toHaveLength(4);
  expect(administradores.every(usuario => usuario.administrador)).toBe(true);
});

test('retornar apenas não administradores', () => {
  const usuarios = retornarNaoAdministradores();
  expect(usuarios).toHaveLength(6);
  expect(usuarios.every(usuario => !usuario.administrador)).toBe(true);
});

test('incluir um novo usuário', () => {
  const novo = incluirUsuario({
    id: 11,
    nome: 'Lucas Mendes',
    email: 'lucas@exemplo.com',
    login: 'lucas',
    senha: 'abc123',
    administrador: false
  });

  expect(novo.id).toBe(11);
  expect(retornarTodos()).toHaveLength(11);
});

test('impedir inclusão de id ou login duplicado', () => {
  expect(() => incluirUsuario({ id: 1, nome: 'Teste', login: 'novo', senha: '123' }))
    .toThrow('Já existe um usuário com esse id.');

  expect(() => incluirUsuario({ id: 11, nome: 'Teste', login: 'ana', senha: '123' }))
    .toThrow('Já existe um usuário com esse login.');
});

test('apagar um usuário', () => {
  const removido = apagarUsuario(10);
  expect(removido.nome).toBe('Juliana Pereira');
  expect(retornarTodos()).toHaveLength(9);
  expect(apagarUsuario(999)).toBeNull();
});

test('atualizar os dados de um usuário', () => {
  const atualizado = atualizarUsuario(2, {
    nome: 'Bruno Atualizado',
    email: 'bruno.novo@exemplo.com',
    administrador: true
  });

  expect(atualizado.nome).toBe('Bruno Atualizado');
  expect(atualizado.email).toBe('bruno.novo@exemplo.com');
  expect(atualizado.administrador).toBe(true);
  expect(retornarAdministradores()).toHaveLength(5);
});

test('retornar null ao atualizar usuário inexistente', () => {
  expect(atualizarUsuario(999, { nome: 'Teste' })).toBeNull();
});
